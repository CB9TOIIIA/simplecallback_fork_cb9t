#Simple Callback Component#
Компонент административной части для модуля [Simple Callback Module](https://github.com/birdkiwi/mod_simplecallback/)
Joomla 3.0+

Скачать компонент: [Все версии](https://github.com/birdkiwi/com_simplecallback/releases/)

**Возможности:**

Компонент позволяет просматривать все сохраненные сообщения из модуля Simple Callback Module. 

![mod_simplecallback screenshot](http://joomla.startler.ru/images/screenshots/com_simplecallback.png)